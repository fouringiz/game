# Ultimate TD — EN Glossary (официальный словарь терминов, v1.0)

> Язык игры — английский. Этот документ — единственный источник официальных EN-имён для всех текстов. Русский — только для сверки в работе. Правило «бумага/эфир»: в документах — официальные имена, сленг — только в голосовых выкриках гарнизонов (EN-выкрики указаны).

## 1. Мир и организации

| EN | RU | Примечание |
|---|---|---|
| The Expedition | Экспедиция | официальное имя, без брендов |
| The Hunger | Голод | универсальное имя роя (документы + эфир) |
| Consumers | Консументы | таксономия каталога Marsh |
| The Precursors | Предтечи | |
| the Veins | Вены планеты | погребённая сеть, проросшая роем |
| The Expeditionary Fund | Экспедиционный фонд | владелец премий |
| Asset Realization Division | Отдел реализации активов | контора Sato |
| Command | Командование | Hayes; бумагу не брендирует |
| The Science Corps | Научный корпус | |
| Xenology Division | Отдел ксенологии | Marsh |
| Commander | Командующий | титул игрока |
| bounty / credits (cr) | премия / кредиты | |
| letters home | письма домой | брифинги между актами |

## 2. Кампания и стратегическая карта

| EN | RU | Примечание |
|---|---|---|
| the Ring | «Кольцо» | стратегическая карта |
| The Gate | Врата | база в центре; потеря = game over |
| The Heart | Сердце | финальный узел |
| Gateway (1/2/3) | Шлюз | сюжетные узлы между кольцами |
| Three Sign-Offs | «Три подписи» | правило вскрытия шлюза; развязано с Signature |
| node | узел | одна TD-партия |
| Digsite | раскоп | научный узел |
| Infrastructure | инфраструктура | корпоративный узел |
| Redoubt | рубеж | военный узел; «Intercept confirmed» |
| Signature | Сигнатура | шкала шума; порог → контратака |
| counterattack | контратака | |
| garrison | гарнизон | плоские 4 башни |
| Sector Profile | профиль сектора | местная популяция по каталогу |
| Appropriations | ассигнования | кампанийная валюта апгрейдов |
| Anomaly / Specimen N | Аномалия / «Образец N» | именованная особь |
| wild edge | дикий край | сторона захода контратак |

## 3. Механики миссии

| EN | RU | Примечание |
|---|---|---|
| power pool | единый пул энергии | |
| brownout | браунаут | −40% скорострельности |
| tower pause / warm-up | пауза башни / прогрев | 2–3 с после снятия |
| rail switch | рельсовая стрелка | |
| Restoration Site / Precursor Ruins | трофейная точка / руины предтеч | |
| restoration | реставрация | ровно 1 волна уязвимости |
| Substation | подстанция | +25 энергии |
| Sensor Mast | сенсорная мачта | +1 волна обзора |
| repair drone | ремонтный дрон | |
| radar | радар | «читает инкубаторы» |
| wave report | отчёт после волны | рапорт Marsh |
| Superweapon | супероружие | здание, заряд от профицита |
| Orbital Cutter | Орбитальный резак | |
| Stasis Field | Стазис-поле | |
| Nanite Swarm | Нанитный рой | |
| Target Priority: First / Strongest / Airborne / Leeches | приоритет цели: первый / сильнейший / летающие / пиявки | бесплатный переключатель |
| Veterancy: Regular → Veteran → Elite | ветеранство: обычная → ветеран → элита | «stripes» — нашивки |
| FEAST ×N («THE SWARM FEASTS»)| «Пир» / «РОЙ ПИРУЕТ ×N» | баннер пиявок |
| Sated Waves | «Сытые волны» | украденное усиливает волны |

## 4. Башни — четыре линейки

| EN | RU | Спец-апгрейды (EN) |
|---|---|---|
| **Turret** (kinetic) | Турель (кинетика) | |
| — Machine Gun | Пулемёт | Fire Radius; Rate of Fire / Stopping Power |
| — Rifle | Винтовка | Kill Shot; Range |
| **Voltaic Tower** | Электробашня | |
| — Tesla | Тесла | Chain Targets; Electrified Ground |
| — Prism | Призма | Beam Duration; Prism Link |
| **Flamethrower** | Огнемёт | |
| — Plasma | Плазма | Scorch Length; White Heat (анти-реген) |
| — Cryojet | Криоструя | Deep Freeze; Brittleness (+15% kinetic по замороженным) |
| **Cannon** | Пушка (навесная) | |
| — Howitzer | Гаубица | Caliber; AP Core |
| — Cluster | Кассета | Salvo Density; Concussion (0.5 s stun) |

Уровни линейки: Level 1 → 2 → 3, выбор ветки на Level 4, спец-апгрейды ×3.

## 5. Орудия предтеч

| EN | RU | Эффект |
|---|---|---|
| Excisor | Эксцизор | стирает цели <15% HP |
| Recall Obelisk | Обелиск отката | откат по собственному маршруту |
| Null Emitter | Нуль-эмиттер | купол, глушит спецспособности |
| Aegis | Эгида | щит построек; сбрасывает Пиявок |
| Awakening: Regular → Awakened → True | «Пробуждение» (семя) | не зафиксировано |

## 6. Касты Голода (official / garrison slang)

| Official EN | Slang EN (выкрики) | RU | Кат. |
|---|---|---|---|
| Forager | "Locusts!" | Фуражир («саранча») | E |
| Carapacid | "Freight!" | Панцирник («трамвай») | C |
| Nurse | "Momma in the flow!" | Санитар («мамка») | B |
| Aeroplankton | "Gnats overhead!" | Аэропланктон («мошкара») | E |
| Courier | "Jackrabbits!" | Курьер («заяц») | D |
| Polyp | "Splitters!" | Полип («матрёшка») | C |
| Testudo | "Turtle up front!" | Тестудо («черепаха») | C |
| Leech | — (official везде) | Пиявка | B |
| Neurocoupler | "Switchman on the junction!" | Стрелочник (офиц. «Нейрокоплер») | B |
| Lithophage | "Wreckers inbound!" | Литофаг («сносчик») | C |
| Coordinator | — (official везде) | Координатор | A |
| Matriarch | "Mother is walking!" | Матриарх («Мать») | босс |

## 7. Каталог мутаций (13)

Счёт выверен: 4+7+2 = **13** мутаций (в паспорте исправлено начиная с v2.2).

**Layer 1 — Resistances:**
| EN | RU |
|---|---|
| Keratinization | Ороговение |
| Grounding ("lightning rods") | Заземление («громоотводы») |
| Mirror Chitin | Зеркальный хитин |
| Glycol Blood | Гликолевая кровь |

**Layer 2 — Geometry:**
| EN | RU |
|---|---|
| Smoke Molt | Дымная линька |
| Sprinter Reflex | Спринтерский рефлекс |
| Dispersal | Рассредоточение |
| Ablative | Аблятив |
| Diffuse Ganglion | Рассеянный ганглий |
| Damper | Демпфер |
| Ash Step | Пепельный шаг |

**Layer 3 — Behavior:**
| EN | RU |
|---|---|
| Bypass Instinct | Обходной инстинкт |
| Pain Surge | Болевой форсаж |

## 8. Ассигнования — 21 узел

**Command branch (мощь в моменте):**
| EN | RU | Цена |
|---|---|---|
| Forward Crew | «Передовой расчёт» | 8 |
| Emergency Start Protocol | «Регламент экстренного пуска» | 6 |
| Emergency Busbars | «Аварийные шины» | 10 |
| Field Stripes | «Полевые нашивки» | 10 |
| +1 Garrison Slot | «+1 слот гарнизона» | 12 |
| Orbital Precharge | «Предзаряд орбитальной батареи» | 16 |
| Protocol "Wall" | «Протокол „Стена"» | 18 |

**Science Corps branch (информация и адаптация):**
| EN | RU | Цена |
|---|---|---|
| Extended Sweep | «Расширенный обзор» | 8 |
| Spectral Markers | «Спектральные маркеры» | 6 |
| Shielded Circuit | «Экранированный контур» | 10 |
| Marked Observer | «Меченый наблюдатель» | 10 |
| Field Xenology | «Полевая ксенология» | 12 |
| Applied Xenology | «Прикладная ксенология» | 16 |
| Deep Reading | «Глубокое чтение» | 18 |

**Corporation branch (темп и экономика):**
| EN | RU | Цена |
|---|---|---|
| Seed Capital | «Стартовый капитал» | 8 |
| Biomaterial Tariff | «Тариф на биоматериал» | 6 |
| Subcontracting | «Субподряд» | 10 |
| Restoration Insurance | «Страховка недостроя» | 10 |
| Bulk Contracts | «Оптовые контракты» | 12 |
| Hunting Bounties | «Охотничьи премии» | 16 |
| Controlling Stake | «Контрольный пакет» | 18 |

## 9. Режимы и монетизация

| EN | RU | Примечание |
|---|---|---|
| The Feeding Grounds | «Кормовые угодья» | бесконечный режим (бывш. рабочее «Тишина») |
| Fund Contracts | «Контракты фонда» | live-ops режим расходников |
| "Radio Silence" pack | пакет отключения рекламы | бывш. «Тишина в эфире» |
| Season 2: The Next Beacon | «Сезон 2 — следующий маяк» | части как главы |
| garrison voice packs | голосовые пакеты гарнизонов | косметика |

## 10. Документы (типы и владельцы)

| EN | Владелец | Что это |
|---|---|---|
| Biomaterial Intake (Form 7-B/bis) | Sato | квитанция после миссии |
| Dispatch No. X-XXX | Hayes | сводки, предупреждения |
| Memorandum No. XXXX-M | Marsh | рапорты, каталог, записки |
| Gateway Unsealing Order | все трое | приказ с тремя подписями (G-1…G-3) |
| Joint Resolution H-1 | все трое | три отказа у Сердца + строка Командующего |
| Commander's Resolution | Commander | финальная подпись: Retain / Seal / Read |
| Notice of Force Majeure | Sato | финальная бумага у Врат |
| Appropriation documents | по фракции | 21 документ узлов деревьев |
| Letters home | Cass / Hayes / Marsh | стыки актов; штамп REVIEWED |
| The Expedition Network | канал Sato | все ролики; слоган «Stay informed. Stay solvent.» |
| Know Your Consumer | ролик | 12 обучающих роликов по кастам |
| Quarterly Update Q1–Q3 | ролик | отчёты на стыках актов + COMMAND NOTE |
| Loading card | агитка | статичный плакат на загрузке |
| Patch | маскот | ремонтный дрон, «not covered» |
